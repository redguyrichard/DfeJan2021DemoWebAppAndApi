﻿using System.Threading.Tasks;
using dfeJan2021DemoApi.Database;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using MySqlConnector;
using System;

namespace dfeJan2021DemoApi.Controllers
{
    [Route("api/[controller]")]
    public class MySqlDfeDataController : ControllerBase
    {
        public AppDb Db { get; }

        public MySqlDfeDataController(AppDb db)
        {
            Db = db;
        }

        // GET api/blog
        [HttpGet]
        public async Task<IActionResult> GetLatest()
        {
            await Db.Connection.OpenAsync();
            var query = new DfeDataQuery(Db);
            var result = await query.LatestPostsAsync();
            return new OkObjectResult(result);
        }
    }

    public class DfeDataQuery
    {
        public AppDb Db { get; }

        public DfeDataQuery(AppDb db)
        {
            Db = db;
        }

        public async Task<List<DfeData>> LatestPostsAsync()
        {
            using var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = @"SELECT * FROM coaData";
            return await ReadAllAsync(await cmd.ExecuteReaderAsync());
        }

        private async Task<List<DfeData>> ReadAllAsync(DbDataReader reader)
        {
            var posts = new List<DfeData>();
            using (reader)
            {
                while (await reader.ReadAsync())
                {
                    var post = new DfeData(Db)
                    {
                        Id = reader.GetInt32(0),
                        DDate = reader.GetDateTime(1),
                        TrustUkprn = reader.GetString(2),
                        AcademyUpin = reader.GetString(3),
                    };
                    posts.Add(post);
                }
            }
            return posts;
        }
    }

    public class DfeData
    {
        internal AppDb Db { get; set; }

        public int Id { get; set; }
        public DateTime DDate { get; set; }
        public string TrustUkprn { get; set; }
        public string AcademyUpin { get; set; }

        public int Account { get; set; }
        public decimal Value { get; set; }

        public DfeData()
        {
        }

        internal DfeData(AppDb db)
        {
            Db = db;
        }

        //public async Task InsertAsync()
        //{
        //    using var cmd = Db.Connection.CreateCommand();
        //    cmd.CommandText = @"INSERT INTO `BlogPost` (`Title`, `Content`) VALUES (@title, @content);";
        //    BindParams(cmd);
        //    await cmd.ExecuteNonQueryAsync();
        //    Id = (int)cmd.LastInsertedId;
        //}

        //public async Task UpdateAsync()
        //{
        //    using var cmd = Db.Connection.CreateCommand();
        //    cmd.CommandText = @"UPDATE `BlogPost` SET `Title` = @title, `Content` = @content WHERE `Id` = @id;";
        //    BindParams(cmd);
        //    BindId(cmd);
        //    await cmd.ExecuteNonQueryAsync();
        //}

        //public async Task DeleteAsync()
        //{
        //    using var cmd = Db.Connection.CreateCommand();
        //    cmd.CommandText = @"DELETE FROM `BlogPost` WHERE `Id` = @id;";
        //    BindId(cmd);
        //    await cmd.ExecuteNonQueryAsync();
        //}

        private void BindId(MySqlCommand cmd)
        {
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@id",
                DbType = DbType.Int32,
                Value = Id,
            });
        }

        private void BindParams(MySqlCommand cmd)
        {
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@dDate",
                DbType = DbType.DateTime,
                Value = DDate,
            });
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@trustUkprn",
                DbType = DbType.String,
                Value = TrustUkprn,
            });
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@academyUpin",
                DbType = DbType.String,
                Value = AcademyUpin,
            });
        }
    }

}
