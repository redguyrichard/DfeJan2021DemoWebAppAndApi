﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using dfeJan2021DemoApi.Models;
using Microsoft.AspNetCore.Http;
using dfeJan2021DemoApi.Database;

namespace dfeJan2021DemoApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SnapshotController : ControllerBase
    {

        private readonly ILogger<WeatherForecastController> _logger;

        private readonly ISqlServerRepository _sqlServerRepository;

        private string[] _coaCodes = { "650400", "650450", "650500", "650550", "845100", "845150", "845200", "845250", "615150", "625150", "627150", "632150", "647150", "820100", "820300", "820350" };

        public SnapshotController(ILogger<WeatherForecastController> logger, ISqlServerRepository sqlServerRepository)
        {
            _logger = logger;
            _sqlServerRepository = sqlServerRepository;
        }

        [HttpGet]
        public IEnumerable<Snapshot> Get()
        {
            //var trustData = new List<Snapshot>();
            //for (int i = 1; i < 6; i++)
            //{
            //    var academyData = new List<AcademyData>();
            //    var coaData = new Dictionary<string, double>();
            //    var rng = new Random();
            //    var randData = Enumerable.Range(0, 16).Select(index => new KeyValuePair<string, double>(_coaCodes[index], (double)rng.Next(-20, 55)));
            //    foreach (var item in randData)
            //    {
            //        coaData.Add(item.Key, item.Value);
            //    }

            //    academyData.Add(new AcademyData { AcademyUpin = 100001, AcademyCoaData = coaData });
            //    academyData.Add(new AcademyData { AcademyUpin = 100002, AcademyCoaData = coaData });

            //    trustData.Add(new Snapshot() { Date = new DateTime(2021, i, 1), TrustCoaData = coaData, Academies = academyData });
            //}

            var snapshotQueryResult = _sqlServerRepository.GetDataSnapshot();

            IEnumerable<Snapshot> query = from ssqrRow in snapshotQueryResult
                        group ssqrRow by ssqrRow.SnapshotDate into dateGroup
                        select new Snapshot
                        {
                            Date = dateGroup.Key,
                            Academies = from dgRow in dateGroup
                                        group dgRow by dgRow.AcademyUpin into academyGroup
                                        select new AcademyData
                                        {
                                            AcademyUpin = academyGroup.Key,
                                            AcademyCoaData = academyGroup.ToDictionary(p => p.CoaAccount.ToString(), p => p.CoaAccountValue)
                                        }
                        };

            return query;
        }

        /*
        [HttpPut("{id:int}")]
        //public IEnumerable<Snapshot> Post(int id, IEnumerable<Snapshot> snapshots)
        // public IActionResult Post([FromBody]OwnerForCreationDto owner)
        public IActionResult Post(int id, IEnumerable<Snapshot> snapshots)
        {
            try
            {
                // if (id != employee.EmployeeId) return BadRequest("Employee ID mismatch");
                // var employeeToUpdate = await employeeRepository.GetEmployee(id);
                // if (employeeToUpdate == null) return NotFound($"Employee with Id = {id} not found");


                // Dapper Contrib example
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    var eventId = 1;
                    var myEvent = connection.Get<Event>(eventId);
                    myEvent.EventName = "New Name";
                    connection.Update(myEvent);
                }

                return new OkObjectResult(snapshots);
                //return CreatedAtRoute("snapshotbyid", snapshots);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside Snapshot->Post action: {ex.Message}");
                return StatusCode(500, "Internal server error");
                // return StatusCode(StatusCodes.Status500InternalServerError, "Error updating data");
            }
        }
        */
    }
}
