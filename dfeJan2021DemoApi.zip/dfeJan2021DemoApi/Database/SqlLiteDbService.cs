﻿using Dapper;
using Microsoft.Data.Sqlite;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace dfeJan2021DemoApi.Database
{
    //public class SqlDbService
    //{
    //}

    public interface IProductRepository
    {
        Task Create(Product product);
    }

    public class ProductRepository : IProductRepository
    {
        private readonly SqlLiteConfig databaseConfig;

        public ProductRepository(SqlLiteConfig databaseConfig)
        {
            this.databaseConfig = databaseConfig;
        }

        public async Task Create(Product product)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            await connection.ExecuteAsync("INSERT INTO dfe (Name, Description) VALUES (@Name, @Description);", product);
        }
    }

    public interface IProductProvider
    {
        Task<IEnumerable<Product>> Get();
    }

    public class ProductProvider : IProductProvider
    {
        private readonly SqlLiteConfig databaseConfig;

        public ProductProvider(SqlLiteConfig databaseConfig)
        {
            this.databaseConfig = databaseConfig;
        }

        public async Task<IEnumerable<Product>> Get()
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            return await connection.QueryAsync<Product>("SELECT rowid AS Id, Name, Description FROM dfe;");
        }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }

}
