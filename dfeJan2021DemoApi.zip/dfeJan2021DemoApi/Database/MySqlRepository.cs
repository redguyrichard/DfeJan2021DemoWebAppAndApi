﻿//using AspNetCoreDapperMySql.Code;
using Dapper;
using Microsoft.Extensions.Options;
//using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using dfeJan2021DemoApi.Models;
using MySqlConnector;

namespace dfeJan2021DemoApi.Database
{
    public class AppDb : IDisposable
    {
        public MySqlConnection Connection { get; }

        public AppDb(string connectionString)
        {
            Connection = new MySqlConnection(connectionString);
        }

        public void Dispose() => Connection.Dispose();
    }

    /*
    internal interface IMySqlRepositoryBase
    {
        List<CoaData> GetCoaData();
    }

    public class MySqlRepositoryBase : IMySqlRepositoryBase
    {
        private readonly IDbConnection _db;

        //public MySqlRepositoryBase()
        //{
        //    _db = new MySqlConnection(connectionStrings.Value.ConnectionString1);
        //}

        //public MySqlRepositoryBase(IOptions<ConnectionStringList> connectionStrings)
        //{
        //    _db = new MySqlConnection(connectionStrings.Value.ConnectionString1);
        //}

        public void Dispose()
        {
            _db.Close();
        }

        public List<CoaData> GetCoaData()
        {
            return _db.Query<CoaData>("SELECT * FROM GLB_Cidade ORDER BY Nome ASC LIMIT 10").ToList();
            // return _db.Query<Cidade>("SELECT * FROM GLB_Cidade WHERE Nome LIKE @Nome ORDER BY Nome ASC LIMIT 10", new { Nome = string.Format("%{0}%", nome) }).ToList();
        }
    }
    */
}