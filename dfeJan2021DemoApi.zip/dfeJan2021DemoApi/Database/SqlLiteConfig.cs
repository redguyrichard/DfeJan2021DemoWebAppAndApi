﻿using Dapper;
using Microsoft.Data.Sqlite;
using System.Linq;

namespace dfeJan2021DemoApi.Database
{
    public class SqlLiteConfig
    {
        public string Name { get; set; }
    }

    public interface IDatabaseBootstrap
    {
        void Setup();
    }

    public class SqlLiteBootstrap : IDatabaseBootstrap
    {
        private readonly SqlLiteConfig databaseConfig;

        public SqlLiteBootstrap(SqlLiteConfig databaseConfig)
        {
            this.databaseConfig = databaseConfig;
        }

        public void Setup()
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            var table = connection.Query<string>("SELECT name FROM sqlite_master WHERE type='table' AND name = 'dfe';");
            var tableName = table.FirstOrDefault();
            if (!string.IsNullOrEmpty(tableName) && tableName == "dfe")
                return;

            connection.Execute("Create Table dfe (" +
                "Name VARCHAR(100) NOT NULL," +
                "Description VARCHAR(1000) NULL);");
        }
    }
}
