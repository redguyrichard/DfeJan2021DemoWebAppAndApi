using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using dfeJan2021DemoApi.Database;
using System.Data;
using System.Data.SqlClient;

namespace dfeJan2021DemoApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            // *** SQLite ***
            //services.AddSingleton(new SqlLiteConfig { Name = Configuration["DatabaseName"] });
            //services.AddSingleton<IDatabaseBootstrap, SqlLiteBootstrap>();
            //services.AddSingleton<IProductProvider, ProductProvider>();
            //services.AddSingleton<IProductRepository, ProductRepository>();

            // *** MySql ***
            // services.AddTransient<AppDb>(_ => new AppDb(Configuration["MySqlConnectionString"]));

            // *** SQL Server ***
            // Inject IDbConnection, with implementation from SqlConnection class.
            // services.AddTransient<IDbConnection>((sp) => new SqlConnection(Configuration["SqlServerConnectionString"]));
            //services.AddScoped<ISqlServerRepository, SqlServerRepository>();

            services.AddScoped<ISqlServerRepository>(s => new SqlServerRepository(Configuration["SqlServerConnectionString"]));

            // Register your regular repositories
            //services.AddScoped<ISqlServerRepository, SqlServerRepository>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IServiceProvider serviceProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            // *** SQLite ***
            // serviceProvider.GetService<IDatabaseBootstrap>().Setup();
        }
    }
}
